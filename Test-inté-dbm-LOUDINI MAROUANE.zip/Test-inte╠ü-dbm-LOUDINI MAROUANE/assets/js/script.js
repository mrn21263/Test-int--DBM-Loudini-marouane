///////////////////////////burger-menu///////////////////////////

document.addEventListener('DOMContentLoaded', () => {
  const burgerMenu = document.querySelector('.burger-menu');
  const navLinks = document.querySelector('.nav-links');
  let isOpen = false;

  burgerMenu.addEventListener('click', () => {
    if (isOpen) {
      hideNavLinks();
      enableScroll();
    } else {
      showNavLinks();
      disableScroll();
    }
    isOpen = !isOpen;
  });

  function hideNavLinks() {
    navLinks.style.opacity = '0';
    setTimeout(() => {
      navLinks.style.display = 'none';
    }, 500);
  }

  function showNavLinks() {
    navLinks.style.display = 'flex';
    setTimeout(() => {
      navLinks.style.opacity = '1';
    }, 0);
  }

  function disableScroll() {
    document.body.style.cssText = 'position: fixed; overflow-y: scroll;';
  }

  function enableScroll() {
    document.body.style.cssText = 'position: ""; overflow-y: auto;';
  }
});


const TOGGLE = document.querySelector('button')

const HANDLE_TOGGLE = () => {
  TOGGLE.setAttribute('aria-pressed', TOGGLE.matches('[aria-pressed=true]') ? false : true)
}

TOGGLE.addEventListener('click', HANDLE_TOGGLE)

const INPUT = document.querySelector('input')

const APPLY_TRANSFORM_BOX = () => {
  TOGGLE.classList.toggle('unset')
}



///////////////////////////Département défilement///////////////////////////


(function() {
  var tabMenu = document.querySelectorAll('.deroule');
  var tabD = document.querySelectorAll('ul ul');

  function deroule(e) {
    e.stopPropagation(); 
    var obj = this.querySelector('ul');
    
    if (!this.open) {
      tabMenu.forEach(ferme);
      this.classList.add('open'); 
      obj.style.maxHeight = obj.scrollHeight + "px"; 
      this.open = true;
    } else {
      this.classList.remove('open'); 
      obj.style.maxHeight = "0"; 
      this.open = false;
    }
  }

  var ferme = function(obj, i) {
    tabD[i].style.maxHeight = "0";
    obj.classList.remove('open');
    obj.open = false;
  }

  var init = function(obj) {
    obj.addEventListener("click", deroule);
    obj.open = false;
  }

  tabMenu.forEach(init);

  window.addEventListener("click", function() {
    tabMenu.forEach(ferme);
  });


})();



///////////////////////////Splide Test///////////////////////////

document.addEventListener('DOMContentLoaded', function () {
  var splide = new Splide('#my-carousel', {
    perPage: 4,                    
    autoplay: true,    
    interval: 5000,    
    pauseOnHover: true, 
    pagination: false,   
    arrows: false,      
    rewind: false, 
    breakpoints: {
      1358: {
        perPage: 3,
      },
      1220: {
        perPage: 2,
      },
      940: {
        perPage: 1,
      },
    },
  });

  var bar = splide.root.querySelector('.my-slider-progress-bar');

  splide.on('mounted move', function () {
    var end  = splide.Components.Controller.getEnd() + 1;
    var rate = Math.min((splide.index + 1) / end, 1);
    bar.style.width = String(100 * rate) + '%';
  });

  splide.mount();
});


///////////////////////////Map///////////////////////////

document.getElementById('puy-de-dome').addEventListener('click', function(event) {
  event.preventDefault(); 
  document.getElementById('mapImage').src = '../assets/images/puydedome.png';
  selectDepartement('Puy-de-Dôme'); 
});

document.getElementById('cantal').addEventListener('click', function(event) {
  event.preventDefault(); 
  document.getElementById('mapImage').src = '../assets/images/cantal.png';
  selectDepartement('Cantal'); 
});

document.getElementById('allier').addEventListener('click', function(event) {
  event.preventDefault(); 
  document.getElementById('mapImage').src = '../assets/images/allier.png';
  selectDepartement('Allier'); 
});

document.getElementById('ain').addEventListener('click', function(event) {
  event.preventDefault(); 
  document.getElementById('mapImage').src = '../assets/images/ain.png';
  selectDepartement('Ain');
});

function selectService(serviceName) {
  document.getElementById("menu-service").textContent = serviceName;
}

function selectAvailability(availability) {
  document.getElementById("menu-disponibilite").textContent = availability;
}

function selectDepartement(departementName) {
  document.getElementById("menu-departement").textContent = departementName;
}



document.body.style.overflowX = 'hidden';

